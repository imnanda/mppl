<?php
/**
 * Created by PhpStorm.
 * User: asmunanda
 * Date: 6/13/2015
 * Time: 1:36 PM
 */
function koneksi_db(){
    $host = "localhost";
    $database = "mppl";
    $user = "root";
    $password = "asdasd150494";
    $link=mysql_connect($host,$user,$password);
    mysql_select_db($database,$link);
    if(!$link)
        echo "Error : ".mysql_error();
    return $link;
}