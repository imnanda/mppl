<?php
/**
 * Created by PhpStorm.
 * User: asmunanda
 * Date: 6/13/2015
 * Time: 2:13 PM
 */
include "db_connect.php";
$notlp = $_POST['notpl'];
$pesan = $_POST['pesan'];
$date = getdate();
//var_dump($notlp);
$link = koneksi_db();
$sql = "INSERT INTO t_sms values('NULL','$pesan','$date')";
$res = mysql_query($sql, $link); // Eksekusi SQL
if ($res) {
    $id_sms = mysql_insert_id($link);
    //mysql_close($link);
    //header("Location:../view_kategori.php");
} else {
    //mysql_close($link);
    ?>
    <div class="error">Terjadi kesalahan dalam penyimpanan data sms.<br></div>
<?php
}
$id_sms = mysql_insert_id($link);
$sql = "SELECT * FROM t_sms WHERE id_sms='$id_sms'";
$res = mysql_query($sql, $link);
if ($res)
{
    $id_sms = mysql_insert_id($link);
    $sql = "INSERT INTO t_outbox_ values('NULL','$id_sms','$date','P')";
    //header("Location:../view_kategori.php");
}
else {
    ?>
    <div class="error">Terjadi kesalahan dalam Ambil data sms.<br></div>
<?php
}
?>
